# jasminetests
using jasmine as in [text](https://www.oreilly.com/library/view/object-oriented-javascript/9781785880568/)

This is a starting place for a simple project with tests. I introduced it (start of chapter 12) along with functions chapter 3 as the minimal requirement for tdd.

To use this:

```
npm install
npm test
```

The test is in the spec folder. The unit under test is functions.js.


